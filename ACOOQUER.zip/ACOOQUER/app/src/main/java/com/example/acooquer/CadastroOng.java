package com.example.acooquer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class CadastroOng extends AppCompatActivity {


    //Declaração das variáveis
    public AlertDialog alerta;

    public void caixa_dialogo_ok(String strTitulo, String strMensagem) {
        //Cria o gerador do AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //define o titulo
        builder.setTitle(strTitulo);
        //define a mensagem
        builder.setMessage(strMensagem);
        //define um botão como OK
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
            }
        });
        //cria o AlertDialog
        alerta = builder.create();
        //Exibe
        alerta.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_ong);
    }

    int rdbGroup;

    public void CliqueCadastroONG (View view){
        criarONG();
        RadioGroup rdpGrp = (RadioGroup) findViewById(R.id.RdbGroup);
        rdbGroup = rdpGrp.getCheckedRadioButtonId();

    }

    private void criarONG() {

        RadioButton rdbEspPsi = (RadioButton) findViewById(R.id.rdbPsicologica);
        RadioButton rdbEspHab = (RadioButton) findViewById(R.id.rdbHabitacional);
        RadioButton rdbEspAli = (RadioButton) findViewById(R.id.rdbAlimenticia);

        //Declaração das variáveis com valores da EditText
        EditText txtNome = (EditText) findViewById(R.id.txtNomeONG);
        EditText txtEmail = (EditText) findViewById(R.id.txtEmailONG);
        EditText txtSenha = (EditText) findViewById(R.id.txtSenhaONG);
        EditText txtCNPJ = (EditText) findViewById(R.id.txtCNPJONG);
        EditText txtCRCE = (EditText) findViewById(R.id.txtCRCE);

        //Recebimento dos valores das EditText
        String textNome = txtNome.getText().toString();
        String textEmail = txtEmail.getText().toString();
        String textSenha = txtSenha.getText().toString();
        String textCNPJ = txtCNPJ.getText().toString();
        String textCRCE = txtCRCE.getText().toString();

        String email = txtEmail.getText().toString();
        String senha = txtSenha.getText().toString();

        if (email == null || email.isEmpty() || senha == null || senha.isEmpty()){
            Toast.makeText(this, "Email ou senha estão vazios!", Toast.LENGTH_SHORT);
            return;
        }

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
            if (task.isSuccessful())
                Log.i("Teste", task.getResult().getUser().getUid());
            salvarONG();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.i("Teste", e.getMessage());
            }
        });
    }

    private void salvarONG(){
        String uid = FirebaseAuth.getInstance().getUid();
        RadioButton rdbEspPsi = (RadioButton) findViewById(R.id.rdbPsicologica);
        RadioButton rdbEspHab = (RadioButton) findViewById(R.id.rdbHabitacional);
        RadioButton rdbEspAli = (RadioButton) findViewById(R.id.rdbAlimenticia);

        //Declaração das variáveis com valores da EditText
        EditText txtNome = (EditText) findViewById(R.id.txtNomeONG);
        EditText txtEmail = (EditText) findViewById(R.id.txtEmailONG);
        EditText txtSenha = (EditText) findViewById(R.id.txtSenhaONG);
        EditText txtCNPJ = (EditText) findViewById(R.id.txtCNPJONG);
        EditText txtCRCE = (EditText) findViewById(R.id.txtCRCE);

        //Recebimento dos valores das EditText
        String nome = txtNome.getText().toString();
        String email = txtEmail.getText().toString();
        String cnpj = txtCNPJ.getText().toString();
        String crce = txtCRCE.getText().toString();
        String especialidade = "";
        if (rdbEspAli.isChecked()){
            especialidade = "Alimentícia";
        }
        else if (rdbEspHab.isChecked()){
            especialidade = "Habitacional";
        }
        else if (rdbEspPsi.isChecked()){
            especialidade = "Psicológica";
        }

        ONG ong = new ONG(uid, nome, email, cnpj, crce, especialidade);
        FirebaseFirestore.getInstance().collection("ongs")
                .add(ong)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.i("Teste", documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("Teste", e.getMessage());
                    }
                });
    }

}