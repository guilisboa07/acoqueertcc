package com.example.acooquer;

import static com.example.acooquer.R.array.Genero;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class CadastroUsuario extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    //Declaração das variáveis
    public AlertDialog alerta;
    String spinnerSex;
    String spinnerGen;

    Spinner spnSex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastrousuario);

        spnSex = findViewById(R.id.spnSexualidade);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Sexualidade, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnSex.setAdapter(adapter);
        spnSex.setOnItemSelectedListener(this);
        spinnerSex = String.valueOf(spnSex.getOnItemSelectedListener());
        Toast.makeText(this, "Item Selecionado: ${R.array.Sexualidade[spnSex.selectedItemPosition]}", Toast.LENGTH_SHORT);

        Spinner spnGen = findViewById(R.id.spnGenero);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, Genero, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnGen.setAdapter(adapter1);
        spnGen.setOnItemSelectedListener(this);
        spinnerGen = String.valueOf(spnGen.getOnItemSelectedListener());
        Toast.makeText(this, "Item Selecionado: ${R.array.Genero[spnGen.selectedItemPosition]}", Toast.LENGTH_SHORT);
    }


    public void caixa_dialogo_ok(String strTitulo, String strMensagem) {
        //Cria o gerador do AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //define o titulo
        builder.setTitle(strTitulo);
        //define a mensagem
        builder.setMessage(strMensagem);
        //define um botão como OK
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
            }
        });
        //cria o AlertDialog
        alerta = builder.create();
        //Exibe
        alerta.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void CliqueCadastroUsuario (View view){
    criarUsuario();
    }

    private void criarUsuario() {
        //Recebimento dos valores das EditText
        EditText txtNomeUsuario = findViewById(R.id.txtNomeUsuario);
        EditText txtEmailUsuario = findViewById(R.id.txtEmailUsuario);
        EditText txtIdadeUsuario = findViewById(R.id.txtIdadeUsuario);
        EditText txtSenhaUsuario = findViewById(R.id.txtSenhaUsuario);
        EditText txtConfirmarSenhaUsuario = findViewById(R.id.txtConfirmarSenhaUsuario);
        EditText txtCPFUsuario = findViewById(R.id.txtCPFUsuario);

        String textNomeUsuario = txtNomeUsuario.getText().toString();
        String textEmailUsuario = txtEmailUsuario.getText().toString();
        String textIdadeUsuario = txtIdadeUsuario.getText().toString();
        String textCPFUsuario = txtCPFUsuario.getText().toString();
        String textSenhaUsuario = txtSenhaUsuario.getText().toString();
        String textConfirmarSenhaUsuario = txtConfirmarSenhaUsuario.getText().toString();

        String email = txtEmailUsuario.getText().toString();
        String senha = txtSenhaUsuario.getText().toString();

        if (email == null || email.isEmpty() || senha == null || senha.isEmpty()){
            Toast.makeText(this, "Email ou senha estão vazios!", Toast.LENGTH_SHORT);
            return;
        }

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful())
                    Log.i("Teste", task.getResult().getUser().getUid());

                salvarUsuario();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.i("Teste", e.getMessage());
            }
        });
    }

    private void salvarUsuario(){
        String uid = FirebaseAuth.getInstance().getUid();
        EditText txtNomeUsuario = findViewById(R.id.txtNomeUsuario);
        EditText txtEmailUsuario = findViewById(R.id.txtEmailUsuario);
        EditText txtIdadeUsuario = findViewById(R.id.txtIdadeUsuario);
        EditText txtCPFUsuario = findViewById(R.id.txtCPFUsuario);

        String sexualidade = spnSex.getSelectedItem().toString();

        String username = txtNomeUsuario.getText().toString();
        String email = txtEmailUsuario.getText().toString();
        String idade = txtIdadeUsuario.getText().toString();
        String cpf = txtCPFUsuario.getText().toString();

        User user = new User(uid, username, email, sexualidade, idade, cpf);
        FirebaseFirestore.getInstance().collection("users")
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.i("Teste", documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("Teste", e.getMessage());
                    }
                });
    }

}