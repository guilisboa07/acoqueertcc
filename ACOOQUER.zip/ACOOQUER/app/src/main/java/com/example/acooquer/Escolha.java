package com.example.acooquer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Escolha extends AppCompatActivity {
    ImageView Pessoa;
    ImageView ONG;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha);

        Pessoa = (ImageView) findViewById(R.id.Pessoa);
        ONG = (ImageView) findViewById(R.id.Ong);

        Pessoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Cadastro = new Intent(Escolha.this, CadastroUsuario.class);
                startActivity(Cadastro);
            }
        });

        ONG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Cadastro = new Intent(Escolha.this, CadastroOng.class);
                startActivity(Cadastro);
            }
        });

    }
}