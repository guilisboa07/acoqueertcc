package com.example.acooquer;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;


import com.etebarian.meowbottomnavigation.MeowBottomNavigation;

public class HomePage extends AppCompatActivity {

    private final int ID_HOME = 1;
    private final int ID_MESSAGE = 2;
    private final int ID_MAP = 3;
    private final int ID_PROFILE = 4;
    private final int ID_SEARCH = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);

        MeowBottomNavigation bottomNavigation = findViewById(R.id.bottomNavigation);
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_HOME,R.drawable.home));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MESSAGE,R.drawable.ic_baseline_message_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MAP,R.drawable.map));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_PROFILE,R.drawable.ic_baseline_person_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_SEARCH,R.drawable.search));

        bottomNavigation.setOnClickMenuListener(new MeowBottomNavigation.ClickListener(){
            @Override
            public void onClickItem(MeowBottomNavigation.Model item){

                Toast.makeText(HomePage.this, "clicked item: " + item.getId(), Toast.LENGTH_SHORT);
            }

        });

      bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
          @Override
          public void onShowItem(MeowBottomNavigation.Model item){

              String name;
              switch (item.getId()){
                  case ID_HOME: name = "Home";
                  break;

                  case ID_MESSAGE: name = "Message";
                      break;

                  case ID_MAP: name = "Map";
                      break;

                  case ID_PROFILE: name = "Profile";
                      break;

                  case ID_SEARCH: name = "Search";
                      break;

                  default: name = "";
              }

              if(name == "Message"){
                  Intent i = new Intent (HomePage.this, Message.class );
                  startActivity(i);
              }

              if(name == "Home"){
                  Intent i = new Intent (HomePage.this, HomePage.class );
                  startActivity(i);
              }

              if(name == "Profile"){
                  Intent i = new Intent (HomePage.this, Perfil.class );
                  startActivity(i);
              }
              if(name == "Map"){
                  Intent i = new Intent (HomePage.this, MapsActivity.class );
                  startActivity(i);
              }
              if(name == "Search"){
                  Intent i = new Intent (HomePage.this, ProcurarONGS.class );
                  startActivity(i);
              }
          }
      });
            bottomNavigation.setCount(ID_PROFILE, "4");
            bottomNavigation.show(ID_HOME, true);

    }
}