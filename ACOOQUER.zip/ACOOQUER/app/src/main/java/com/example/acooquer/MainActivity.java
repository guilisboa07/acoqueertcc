package com.example.acooquer;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    RadioButton rdbOng;
    RadioButton rdbUsuario;
    SQLiteDatabase db;
    Button btn;
    public AlertDialog alerta;

    public void caixa_dialogo_ok(String strTitulo, String strMensagem) {
        //Cria o gerador do AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //define o titulo
        builder.setTitle(strTitulo);
        //define a mensagem
        builder.setMessage(strMensagem);
        //define um botão como OK
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
            }
        });
        //cria o AlertDialog
        alerta = builder.create();
        //Exibe
        alerta.show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tv = (TextView) findViewById(R.id.cadastro);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Cadastro = new Intent(MainActivity.this, Escolha.class);
                startActivity(Cadastro);
            }
        });
    }
    public void CliqueLogin(View v) {
        EditText txtemail = (EditText) findViewById(R.id.txtEmail);
        EditText txtsenha = (EditText) findViewById(R.id.txtSenha);
        String email = txtemail.getText().toString();
        String senha = txtsenha.getText().toString();

        Log.i("Teste", email);
        Log.i("Teste", senha);

        if (email == null || email.isEmpty() || senha == null || senha.isEmpty()){
            Toast.makeText(this, "Email ou senha estão vazios!", Toast.LENGTH_SHORT);
            return;
        }

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, senha)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                            Log.i("Teste", task.getResult().getUser().getUid());
                            Intent telaPrincipal = new Intent(MainActivity.this, HomePage.class);
                            startActivity(telaPrincipal);
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("Teste", e.getMessage());
                    }
                });
    }


        }






