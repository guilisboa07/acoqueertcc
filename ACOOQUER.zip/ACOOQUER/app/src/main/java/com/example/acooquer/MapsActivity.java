package com.example.acooquer;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.acooquer.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private final int ID_HOME = 1;
    private final int ID_MESSAGE = 2;
    private final int ID_MAP = 3;
    private final int ID_PROFILE = 4;
    private final int ID_SEARCH = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        MeowBottomNavigation bottomNavigation = findViewById(R.id.bottomNavigation);
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_HOME,R.drawable.home));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MESSAGE,R.drawable.ic_baseline_message_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MAP,R.drawable.map));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_PROFILE,R.drawable.ic_baseline_person_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_SEARCH,R.drawable.search));

        bottomNavigation.setOnClickMenuListener(new MeowBottomNavigation.ClickListener(){
            @Override
            public void onClickItem(MeowBottomNavigation.Model item){

                Toast.makeText(MapsActivity.this, "clicked item: " + item.getId(), Toast.LENGTH_SHORT);
            }

        });

        bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
            @Override
            public void onShowItem(MeowBottomNavigation.Model item){

                String name;
                switch (item.getId()){
                    case ID_HOME: name = "Home";
                        break;

                    case ID_MESSAGE: name = "Message";
                        break;

                    case ID_MAP: name = "Map";
                        break;

                    case ID_PROFILE: name = "Profile";
                        break;

                    case ID_SEARCH: name = "Search";
                        break;

                    default: name = "";
                }
                if(name == "Map"){
                    Intent i = new Intent (MapsActivity.this, MapsActivity.class );
                    startActivity(i);
                }

                if(name == "Perfil"){
                    Intent i = new Intent (MapsActivity.this, Perfil.class );
                    startActivity(i);
                }

                if(name == "Home"){
                    Intent i = new Intent (MapsActivity.this, HomePage.class );
                    startActivity(i);
                }

                if(name == "Search"){
                    Intent i = new Intent (MapsActivity.this, ProcurarONGS.class );
                    startActivity(i);
                }
                if(name == "Message"){
                    Intent i = new Intent (MapsActivity.this, Message.class );
                    startActivity(i);
                }

            }
        });
        bottomNavigation.setCount(ID_HOME, "1");
        bottomNavigation.show(ID_PROFILE, true);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }
}