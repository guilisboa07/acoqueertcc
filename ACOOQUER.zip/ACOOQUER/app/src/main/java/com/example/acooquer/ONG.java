package com.example.acooquer;

public class ONG {
    private final String uuid;
    private final String nome;
    private final String email;
    private final String cnpj;
    private final String crce;
    private final String especialidade;

    public ONG(String uuid, String nome, String email, String cnpj, String crce, String especialidade) {
        this.uuid = uuid;
        this.nome = nome;
        this.email = email;
        this.cnpj = cnpj;
        this.crce = crce;
        this.especialidade = especialidade;
    }
    public String getUuid(){
        return uuid;
    }
    public String getNome() {
        return nome;
    }
    public String getEmail(){
        return email;
    }
    public String getCNPJ() {
        return cnpj;
    }
    public String getCRCE(){
        return crce;
    }
    public String getEspecialidade() {
        return especialidade;
    }
}
