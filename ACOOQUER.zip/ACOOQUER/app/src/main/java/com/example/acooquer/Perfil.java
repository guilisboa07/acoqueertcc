package com.example.acooquer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.lang.ref.Reference;
import java.util.Collections;



public class Perfil extends AppCompatActivity {
    String usuarioID;

    private final int ID_HOME = 1;
    private final int ID_MESSAGE = 2;
    private final int ID_MAP = 3;
    private final int ID_PROFILE = 4;
    private final int ID_SEARCH = 5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
        ExibirDados();

        MeowBottomNavigation bottomNavigation = findViewById(R.id.bottomNavigation);
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_HOME,R.drawable.home));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MESSAGE,R.drawable.ic_baseline_message_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MAP,R.drawable.map));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_PROFILE,R.drawable.ic_baseline_person_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_SEARCH,R.drawable.search));

        bottomNavigation.setOnClickMenuListener(new MeowBottomNavigation.ClickListener(){
            @Override
            public void onClickItem(MeowBottomNavigation.Model item){

                Toast.makeText(Perfil.this, "clicked item: " + item.getId(), Toast.LENGTH_SHORT);
            }

        });

        bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
            @Override
            public void onShowItem(MeowBottomNavigation.Model item){

                String name;
                switch (item.getId()){
                    case ID_HOME: name = "Home";
                        break;

                    case ID_MESSAGE: name = "Message";
                        break;

                    case ID_MAP: name = "Map";
                        break;

                    case ID_PROFILE: name = "Profile";
                        break;

                    case ID_SEARCH: name = "Search";
                        break;

                    default: name = "";
                }
                if(name == "Map"){
                    Intent i = new Intent (Perfil.this, MapsActivity.class );
                    startActivity(i);
                }

                if(name == "Profile"){
                    Intent i = new Intent (Perfil.this, Perfil.class );
                    startActivity(i);
                }

                if(name == "Home"){
                    Intent i = new Intent (Perfil.this, HomePage.class );
                    startActivity(i);
                }

                if(name == "Search"){
                    Intent i = new Intent (Perfil.this, ProcurarONGS.class );
                    startActivity(i);
                }
                if(name == "Message"){
                    Intent i = new Intent (Perfil.this, Message.class );
                    startActivity(i);
                }

            }
        });
        bottomNavigation.setCount(ID_HOME, "1");
        bottomNavigation.show(ID_PROFILE, true);

    }
    private void ExibirDados(){
        //DATABASE
        TextView textNome = findViewById(R.id.nome_exibir);
        TextView textEmail = findViewById(R.id.email_exibir);
        TextView textSexualidade = findViewById(R.id.sexualidade_exibir);
        TextView textIdade = findViewById(R.id.idade_exibir);
        TextView textSenha = findViewById(R.id.senha_exibir);
        TextView textCPF = findViewById(R.id.cpf_exibir);
        String uid = FirebaseAuth.getInstance().getUid();

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference  databaseReference;
        db.collection("users").whereEqualTo("uuid", uid).get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()){
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        Log.d("Teste", document.getId() + " => " + document.getData());
                    }
                } else {
                    Log.d("Teste", "Error getting documents: ", task.getException());
                }
            }
        });
        DocumentReference dcRef = db.collection("users").document(usuarioID);
        dcRef.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot dcSnap, @Nullable FirebaseFirestoreException error) {
            if (dcSnap != null){
                textNome.setText(dcSnap.getString("username"));
                textEmail.setText(dcSnap.getString("email"));
                textSexualidade.setText(dcSnap.getString("sexualidade"));
                textIdade.setText(dcSnap.getString("idade"));
                textSenha.setText(dcSnap.getString("senha"));
                textCPF.setText(dcSnap.getString("cpf"));
            }
            }
        });
    }


}


