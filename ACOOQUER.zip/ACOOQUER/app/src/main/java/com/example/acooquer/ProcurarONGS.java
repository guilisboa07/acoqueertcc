package com.example.acooquer;

import android.content.Intent;
import android.os.Bundle;

import com.etebarian.meowbottomnavigation.MeowBottomNavigation;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.acooquer.databinding.ActivityProcurarOngsBinding;

public class ProcurarONGS extends AppCompatActivity {

  //  private AppBarConfiguration appBarConfiguration;
    //private ActivityProcurarOngsBinding binding;
  private final int ID_HOME = 1;
    private final int ID_MESSAGE = 2;
    private final int ID_MAP = 3;
    private final int ID_PROFILE = 4;
    private final int ID_SEARCH = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MeowBottomNavigation bottomNavigation = findViewById(R.id.bottomNavigation);
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_HOME,R.drawable.home));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MESSAGE,R.drawable.ic_baseline_message_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_MAP,R.drawable.map));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_PROFILE,R.drawable.ic_baseline_person_24));
        bottomNavigation.add( new MeowBottomNavigation.Model(ID_SEARCH,R.drawable.search));


        bottomNavigation.setOnClickMenuListener(new MeowBottomNavigation.ClickListener(){
            @Override
            public void onClickItem(MeowBottomNavigation.Model item){

                Toast.makeText(ProcurarONGS.this, "clicked item: " + item.getId(), Toast.LENGTH_SHORT);
            }

        });

        bottomNavigation.setOnShowListener(new MeowBottomNavigation.ShowListener(){
            @Override
            public void onShowItem(MeowBottomNavigation.Model item){

                String name;
                switch (item.getId()){
                    case ID_HOME: name = "Home";
                        break;

                    case ID_MESSAGE: name = "Message";
                        break;

                    case ID_MAP: name = "Map";
                        break;

                    case ID_PROFILE: name = "Profile";
                        break;

                    case ID_SEARCH: name = "Search";
                        break;

                    default: name = "";
                }

                if(name == "Message"){
                    Intent i = new Intent (ProcurarONGS.this, Message.class );
                    startActivity(i);
                }

                if(name == "Home"){
                    Intent i = new Intent (ProcurarONGS.this, HomePage.class );
                    startActivity(i);
                }

                if(name == "Profile"){
                    Intent i = new Intent (ProcurarONGS.this, Perfil.class );
                    startActivity(i);
                }
                if(name == "Map"){
                    Intent i = new Intent (ProcurarONGS.this, MapsActivity.class );
                    startActivity(i);
                }
                if(name == "Search"){
                    Intent i = new Intent (ProcurarONGS.this, ProcurarONGS.class );
                    startActivity(i);
                }
            }
        });
        bottomNavigation.setCount(ID_PROFILE, "4");
        bottomNavigation.show(ID_HOME, true);

        //binding = ActivityProcurarOngsBinding.inflate(getLayoutInflater());
        //setContentView(binding.getRoot());

        //setSupportActionBar(binding.toolbar);

        //NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_procurar_ongs);
        //appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        //NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        //binding.fab.setOnClickListener(new View.OnClickListener() {
          //  @Override
            //public void onClick(View view) {
              //  Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //        .setAction("Action", null).show();
           // }
      //  });
    }

   // @Override
   // public boolean onSupportNavigateUp() {
     //   NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_procurar_ongs);
      //  return NavigationUI.navigateUp(navController, appBarConfiguration)
        //        || super.onSupportNavigateUp();
    //}
}