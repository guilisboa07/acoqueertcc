package com.example.acooquer;

public class User {
    private final String uuid;
    private final String username;
    private final String email;
    private final String sexualidade;
    private final String idade;
    private final String cpf;

    public User(String uuid, String username, String email, String sexualidade, String idade, String cpf) {
        this.uuid = uuid;
        this.username = username;
        this.email = email;
        this.sexualidade = sexualidade;
        this.idade = idade;
        this.cpf = cpf;
    }
    public String getUuid(){
        return uuid;
    }
    public String getUsername() {
        return username;
    }
    public String getEmail(){
        return email;
    }
    public String getSexualidade() {
        return sexualidade;
    }
    public String getIdade(){
        return idade;
    }
    public String getcpf() {
        return cpf;
    }
}
