package com.example.acooquer;

public class Usuario {

    private int id;
    private String nome;
    private String CPF;
    private String sexualidade;
    private String genero;
    private String idade;
    private static String email;
    private static String senha;

    public int getId(){
        return id;
    }
    public void setId(){this.id = id;    }
    public String getName(){
        return nome;
    }
    public void setName(){
        this.nome = nome;
    }
    public static String getEmail() {return email;}
    public void setEmail(String email) {this.email = this.email;}
    public String getCPF(){
        return CPF;
    }
    public void setCPF(){
        this.CPF = CPF;
    }
    public String getSexualidade(){
        return sexualidade;
    }
    public void setSexualidade(){
        this.sexualidade = sexualidade;
    }
    public String getGenero(){
        return genero;
    }
    public void setGenero(){
        this.genero = genero;
    }
    public String getIdade(){
        return idade;
    }
    public void setIdade(){
        this.idade = idade;
    }

    public static String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
}
